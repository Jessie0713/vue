<?php
    $name = $_REQUEST["name"];
    $age = $_REQUEST["age"];

    echo $name." @@ ".$age;

    // echo "Hello";
?>