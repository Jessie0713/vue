<script>
import Vue from 'vue'
import VueRouter from 'vue-router'

import About from './About'
import Products from './Products'

import AboutHome from './AboutHome'
import AboutYou from './AboutYou'
import AboutMe from './AboutMe'

Vue.use(VueRouter)

export default {
    router: new VueRouter({
        mode: 'history',  //hash by default
        routes: [  //要在哪裡 render 這個組件？
                   //設定固定路徑: http://localhost:8080/about 和 http://localhost:8080/products
                   //並顯示固定的組件: About 和 Products
            // {path: '/about', component: About},
            
            {
                path: '/about', 
                component: About,
                children: [
                    {path: '', component: AboutHome},
                    {path: 'you', component: AboutYou},
                    {path: 'me', component: AboutMe},
                ],
            },

            // {path: '/products', component: Products},
            {
                // path: '/products', 
                // path: '/products/:item',  //自訂名稱: item, id, sn.... 
                path: '/products/:item?',  //加『?』代表 products 後面的路徑可有可無


                component: Products,
            },

        ],
    }),
  
}
</script>

<template>
  <div>
      <p>
          <!-- <a href=""></a> -->
          <router-link to="/about"> About </router-link> | 
          <router-link to="/products"> Products </router-link>
      </p>
      <hr>
      <router-view></router-view>
  </div>
</template>