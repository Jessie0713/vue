<template>
    <div>
        <h3>You</h3>
    </div>
</template>

<style scoped>
    h3{
        font: bold 28px Calibri;
        color: lightseagreen;
    }
</style>