<template>
    <div>
        <h3>Home</h3>
    </div>
</template>

<style scoped>
    h3{
        font: bold 28px Calibri;
        color: lightskyblue;
    }
</style>