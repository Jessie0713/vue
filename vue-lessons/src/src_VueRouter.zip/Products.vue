<template>
    <div>
        <h1> [Products] </h1>
        <!-- <h3> {{$route.params.item}} </h3> -->

        <!-- 要用 computed 處理 -->
        <h3> {{item}} </h3>
    </div>
</template>
<script>
const items = {
    10: 'Hat',
    20: 'Shoes',
    30: 'T-shirt',
    40: 'Mac Pro',
    50: 'iPad Air',
    60: 'iPhone',
    70: 'Nothing',
};
export default {
    computed: {
        item(){
            return items[this.$route.params.item];  // http://localhost:8081/products/50
            //return items[this.$route.query.item];  // http://localhost:8081/products?item=10
        },
    },
    
    
}
</script>

<style scoped>
    h1{
        color: darkgreen;
        font: bold 40px Calibri;
    }
</style>
