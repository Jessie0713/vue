import Vue from 'vue'

// 2. 修改 main.js
import Vuex from 'vuex'

Vue.use(Vuex);

const store = new Vuex.Store({  //差別在這裡
    state: { 
       count: 0,
    },
    mutations: {  
        addCount(state){
            state.count += 1;
        },
    },
});


// 1. 不修改 main.js
// import Vuex,{Store} from 'vuex'
// Vue.use(Vuex);

// const store = new Store({
//     state: {   //類似 new Vue() 裡面的 data
//         count: 0,
//     },
//     mutations: {  //類似 new Vue() 裡面的 methods
//                   // Vuex 裡面只有 mutations 可以修改 state 裡面的值
//         addCount(state){
//             state.count += 1;
//         },
//     },
// });

export default store;

